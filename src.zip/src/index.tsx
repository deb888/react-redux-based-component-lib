

import React from 'react';
import TestComponent from "./test-component/test-component";
import { Provider } from 'react-redux';
import { store } from './redux/store';
const Root = (props) => (
  <Provider store={store}>
    <TestComponent theme={props.theme}/>
  </Provider>
);
export {Root} 
