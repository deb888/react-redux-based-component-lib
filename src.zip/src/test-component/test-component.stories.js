import React from "react";
import TestComponent from "./test-component";
import {Root} from "../index"
export default {
  title: "TestComponent"
};

export const Primary = () => <Root theme="primary" />;

export const Secondary = () => <Root theme="secondary" />;
