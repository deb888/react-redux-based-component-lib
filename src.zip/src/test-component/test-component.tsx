import React from "react";
import { connect } from 'react-redux';

import "./test-component.scss";
import {getPalData} from "../redux/actions/pal/paldata"
interface IProps {
  theme: "primary" | "secondary";
  getPalData:() =>{}
}
interface IState{
  palData:any[]
}
const handlePalData = (values: any) => {
  console.log('values', values);
 
}
class TestComponent extends React.Component<any, IState>  {
componentDidMount(){
this.props.getPalData();
}
  render(){
    const props=this.props;
    return (

      <div className={`test-component test-component-${props.theme}`}>
      <h1 className="heading">I'm the test component</h1>
      <h2>Working</h2>
    </div>
    )
  }
  
  
    
  
 
}
const mapStateToProps = state => ({
  palData: state.data
});

export default connect(mapStateToProps, { getPalData })(TestComponent);


