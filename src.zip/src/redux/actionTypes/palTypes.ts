export const PAL_DATA = 'PAL_DATA';
