import { combineReducers } from 'redux';
import palReducer from './pal';

const rootReducer = combineReducers({
  paldata: palReducer,
});

export default rootReducer;