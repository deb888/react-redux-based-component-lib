import { PAL_DATA } from '../actionTypes/palTypes';
import { PalState, PalTypes } from '../actions/pal/paldata.d';

const INITIAL_STATE: PalState = {
  data: [],
};

function palReducer(state = INITIAL_STATE, action: PalTypes): PalState {
  switch (action.type) {
    case PAL_DATA: {
      return {
        ...state,
        data: [action.payload, ...state.data],
      };
    }
    default:
      return state;
  }
}

export default palReducer;