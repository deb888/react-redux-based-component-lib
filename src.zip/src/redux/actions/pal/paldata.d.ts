export interface PalData {
    userAddress: string;
    userAge: number;
    userBankName: string;
    userDOB: string;
    userGender: string;
    userMobileNumber: string;
    userName: string;
    useraccountNumber: string;
    userbankAddress: string;
}

export interface PalState {
    data: PalData[];
}

export interface PalAction {
    type: string;
    payload: any;
}

export type PalTypes = PalAction;